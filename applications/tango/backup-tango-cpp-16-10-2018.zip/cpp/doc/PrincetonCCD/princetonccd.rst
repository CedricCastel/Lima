PrincetonCCD C++ Tango device
=============================