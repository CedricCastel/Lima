Hamamatsu C++ Tango device
==========================