Pco C++ Tango device
====================