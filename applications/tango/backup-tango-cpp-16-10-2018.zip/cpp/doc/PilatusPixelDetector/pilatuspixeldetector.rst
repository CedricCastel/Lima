PilatusPixelDetector C++ Tango device
=====================================