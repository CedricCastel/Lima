PerkinElmer C++ Tango device
============================