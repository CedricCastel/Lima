SimulatorCCD C++ Tango device
=============================