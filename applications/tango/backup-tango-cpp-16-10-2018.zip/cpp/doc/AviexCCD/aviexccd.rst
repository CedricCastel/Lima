AviexCCD C++ Tango device
=========================