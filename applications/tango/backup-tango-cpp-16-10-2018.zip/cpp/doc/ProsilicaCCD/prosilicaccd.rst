ProsilicaCCD C++ Tango device
=============================