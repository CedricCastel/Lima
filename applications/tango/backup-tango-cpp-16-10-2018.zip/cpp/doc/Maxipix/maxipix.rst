Maxipix C++ Tango device
=========================