# Lima-camera-slsjungfrau
SLS JungFrau detector
