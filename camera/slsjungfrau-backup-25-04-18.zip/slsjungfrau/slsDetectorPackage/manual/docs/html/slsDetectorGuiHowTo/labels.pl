# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/sec:trimdir/;
$external_labels{$key} = "$URL/" . q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:encal/;
$external_labels{$key} = "$URL/" . q|node16.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/sec:trimdir/;
$external_latex_labels{$key} = q|1.6|; 
$noresave{$key} = "$nosave";

1;

