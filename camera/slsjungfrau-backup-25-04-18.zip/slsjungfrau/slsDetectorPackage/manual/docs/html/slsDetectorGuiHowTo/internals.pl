# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/sec:trimdir/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:encal/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

1;

