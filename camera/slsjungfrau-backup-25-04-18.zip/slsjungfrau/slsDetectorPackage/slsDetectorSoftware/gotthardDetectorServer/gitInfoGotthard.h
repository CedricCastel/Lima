#define GITURL "git@github.com:slsdetectorgroup/slsDetectorPackage.git"
#define GITREPUUID "675d69392a6497d42b23057c7c8783c8dad768d0"
#define GITAUTH "Dhanya_Thattil"
#define GITREV 0x3447
#define GITDATE 0x20180227
#define GITBRANCH "3.1.0-rc"
