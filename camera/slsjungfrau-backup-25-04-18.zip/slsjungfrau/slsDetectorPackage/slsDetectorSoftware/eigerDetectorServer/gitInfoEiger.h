#define GITURL "git@github.com:slsdetectorgroup/slsDetectorPackage.git"
#define GITREPUUID "afac5be3c3674fe87044d3b7a54471291698d4ba"
#define GITAUTH "Dhanya_Thattil"
#define GITREV 0x3467
#define GITDATE 0x20180319
#define GITBRANCH "3.1.1-rc"
