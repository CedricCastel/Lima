#define GITURL "git@github.com:slsdetectorgroup/slsDetectorPackage.git"
#define GITREPUUID "b389402d647e939342dbb2c9317c688c0eb6b105"
#define GITAUTH "Erik_Frojdh"
#define GITREV 0x3458
#define GITDATE 0x20180309
#define GITBRANCH "3.1.0-rc"
